#include <math.h>
#include <stdio.h>

#include <omp.h>

#include "color.h"
#include "log.h"
#include "sinoscope.h"

int sinoscope_image_openmp(sinoscope_t* sinoscope) {
	return -1;
}
