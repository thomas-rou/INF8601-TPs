#include <stdio.h>

extern "C" {
#include "filter.h"
#include "pipeline.h"
}

int pipeline_tbb(image_dir_t* image_dir) {
    return -1;
}
