#include <stdio.h>

#include "filter.h"
#include "pipeline.h"

int pipeline_pthread(image_dir_t* image_dir) {
	return -1;
}
